module.exports = {
    'linkedinAuth': {
      'clientID': '861l0azn6r38pu', // your App ID
      'clientSecret': 'G9pbrTzqUaS7gR1G', // your App Secret
      'callbackURL': 'http://127.0.0.1:3000/auth/linkedin/callback'
    }
  }